let startTime = 0;
let elapsedTime = 0;
let timerInterval;
let isRunning = false;
let laps = [];

const timeDisplay = document.getElementById('time');
const millisDisplay = document.getElementById('millis');
const startStopButton = document.getElementById('startStop');
const resetButton = document.getElementById('reset');
const lapButton = document.getElementById('lap');
const lapsContainer = document.getElementById('laps');

// Load the saved state from storage when the popup is opened
chrome.storage.sync.get(['startTime', 'elapsedTime', 'isRunning', 'laps'], (data) => {
  if (data.startTime && data.isRunning) {
    startTime = data.startTime;
    elapsedTime = Date.now() - startTime;
    startStopwatch(); // Resume the stopwatch if it was running
  } else {
    elapsedTime = data.elapsedTime || 0;
  }
  laps = data.laps || [];
  updateDisplay();
  updateLapsDisplay();
});

function formatTime(time) {
  let hours = Math.floor(time / 3600000);
  let minutes = Math.floor((time % 3600000) / 60000);
  let seconds = Math.floor((time % 60000) / 1000);
  let milliseconds = Math.floor((time % 1000));
  return {
    formattedTime:
      String(hours).padStart(2, '0') + ':' +
      String(minutes).padStart(2, '0') + ':' +
      String(seconds).padStart(2, '0'),
    millis: '.' + String(milliseconds).padStart(3, '0')
  };
}

function updateDisplay() {
  const { formattedTime, millis } = formatTime(elapsedTime);
  timeDisplay.textContent = formattedTime;
  millisDisplay.textContent = millis;
}

function startStopwatch() {
  startTime = Date.now() - elapsedTime;
  timerInterval = setInterval(() => {
    elapsedTime = Date.now() - startTime;
    updateDisplay();
  }, 10); // Update every 10 ms for milliseconds display
  isRunning = true;
  saveState();
}

function stopStopwatch() {
  clearInterval(timerInterval);
  isRunning = false;
  saveState();
}

function saveState() {
  chrome.storage.sync.set({
    startTime: isRunning ? startTime : null,
    elapsedTime: elapsedTime,
    isRunning: isRunning,
    laps: laps
  });
}

function addLap() {
  const { formattedTime, millis } = formatTime(elapsedTime);
  const lapTime = `${formattedTime}${millis}`;
  laps.push(lapTime);
  saveState();
  updateLapsDisplay();
}

function updateLapsDisplay() {
  lapsContainer.innerHTML = '';
  laps.forEach((lapTime, index) => {
    const lapElement = document.createElement('div');
    lapElement.textContent = `Lap ${index + 1}: ${lapTime}`;
    lapsContainer.appendChild(lapElement);
  });
}

startStopButton.addEventListener('click', () => {
  if (!isRunning) {
    startStopwatch();
    startStopButton.textContent = 'Stop';
  } else {
    stopStopwatch();
    startStopButton.textContent = 'Start';
  }
});

resetButton.addEventListener('click', () => {
  stopStopwatch();
  elapsedTime = 0;
  startTime = 0;
  laps = [];
  updateDisplay();
  updateLapsDisplay();
  startStopButton.textContent = 'Start';
  saveState();
});

lapButton.addEventListener('click', () => {
  if (isRunning) {
    addLap();
  }
});
